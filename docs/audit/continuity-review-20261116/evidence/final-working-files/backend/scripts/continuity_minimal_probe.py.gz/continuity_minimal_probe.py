"""Offline-only preparation for a NEW minimal continuity condition.

This is deliberately NOT a live acceptance driver. No subcommand starts Core,
discovers models, sends HTTP, resumes a Worker or executes a tool. ``prepare``
creates an exclusive protocol, not permission to execute it. ``audit-ledger``
observes a prepared workspace read-only; it cannot establish Agent Recall.

From backend (no additional dependencies or environment settings required):
  .venv/bin/python scripts/continuity_minimal_probe.py preflight --workspace /NEW/ABS/PATH
  .venv/bin/python scripts/continuity_minimal_probe.py prepare --workspace /NEW/ABS/PATH
  .venv/bin/python scripts/continuity_minimal_probe.py audit-ledger --workspace /PREPARED/PATH

Credentials use the existing FORGE_PROVIDER_CREDENTIAL_REF environment contract
only. Neither credential values nor exception/Provider bodies are published.
Live execution is intentionally unavailable until the protocol gaps are closed
and the user separately authorizes it. Never substitute the old large driver.
"""

import argparse
import hashlib
import json
import os
import re
import sqlite3
import subprocess
import sys
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
SCRIPTS = Path(__file__).resolve().parent
HISTORY_PATH = "docs/audit/superagent/capability-completion-handoff-verification.json"
HISTORY_SHA256 = "9ba167532800222a2e129c080b6045731cbee40a598366ff1087e8880f5b1a8c"
MODEL = "global:deepseek-v4.1-flash-sg"
BASE_URL = "http://127.0.0.1:7863/v1"
OPENING_CALLS, OPENING_TOKENS = 99, 1089785
STAGE_CALL_CAP, STAGE_TOKEN_CAP = 160, 2500000
NEW_CALL_CAP, NEW_TOKEN_CAP = 12, 160000
PROTOCOL_NAME = "continuity-minimal-protocol.json"
GAPS = [
    "no_live_scenario_driver_or_gateway_wiring",
    "no_inference_barrier_for_thread_injection_and_artifact_content_oracle",
    "no_agent_selected_project_switch_and_cross_project_write_oracle",
    "no_quiescent_compaction_process_store_restart_and_agent_recall_driver",
    "no_atomic_campaign_admission_lock_across_other_workspaces",
    "no_independent_current_source_full_regression_or_live_authorization",
]


class Refused(RuntimeError):
    """Fixed local error codes only; no raw exception strings reach output."""


class SafeParser(argparse.ArgumentParser):
    def error(self, message):
        # argparse normally echoes unknown argv, which could include an accidental key.
        print(json.dumps({"status": "refused", "failure_code": "invalid_cli_arguments",
                          "provider_requests_by_this_command": 0}))
        raise SystemExit(2)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2,
                       allow_nan=False) + "\n").encode("utf-8")


def history(repo=REPO):
    """Pin the inherited denominator AND all four original failed results."""
    data = (repo / HISTORY_PATH).read_bytes()
    if sha(data) != HISTORY_SHA256:
        raise Refused("historical_anchor_changed_manual_reconciliation_required")
    anchor = json.loads(data)
    expected = {
        "attempts": OPENING_CALLS, "settled": OPENING_CALLS,
        "charged_or_reserved_tokens": OPENING_TOKENS,
        "attempt_ceiling": STAGE_CALL_CAP, "token_ceiling": STAGE_TOKEN_CAP,
    }
    if any(anchor["completion_stage_accounting"].get(k) != v for k, v in expected.items()):
        raise Refused("historical_totals_mismatch")
    retained = []
    for reference in [*anchor["prior_results_retained"], anchor["latest_real_result"]]:
        path = repo / reference["path"]
        data = path.read_bytes()
        if sha(data) != reference["sha256"]:
            raise Refused("historical_result_changed")
        result = json.loads(data)
        retained.append({**reference, "status": result["status"],
                         "accounting": result["accounting"]})
    if (sum(r["accounting"]["attempts"] for r in retained) != OPENING_CALLS
            or sum(r["accounting"]["charged_or_reserved_tokens"] for r in retained)
            != OPENING_TOKENS):
        raise Refused("historical_result_sum_mismatch")
    return {
        **expected, "anchor": {"path": HISTORY_PATH, "sha256": HISTORY_SHA256},
        "retained_failed_conditions": retained,
        "previous_closed_stages": {
            "reference": anchor["prior_closed_stage_index"],
            "included_in_this_stage_denominator": False,
            "usage_and_effects": "retain_original_unknowns_no_refund_no_replay",
            "note": "Earlier 155-attempt stage and other historical stages stay separate.",
        },
    }


def source_freeze(repo=REPO):
    """Current dirty bytes, not HEAD alone, bind the proposed protocol."""
    def git(*args):
        result = subprocess.run(
            ["git", "--no-optional-locks", "-c", "core.fsmonitor=false", *args],
            cwd=repo, env={k: os.environ[k] for k in ("PATH", "SYSTEMROOT") if k in os.environ},
            capture_output=True, check=True, timeout=15,
        )
        return result.stdout

    def manifest():
        files = set()
        for folder in ("backend/src", "backend/scripts", "backend/tests"):
            files.update((repo / folder).rglob("*.py"))
        files.update(repo / p for p in (
            "AGENTS.md", "README.md", "backend/pyproject.toml", "backend/requirements-lock.txt",
            "docs/SUPERAGENT_NEXT_ENV_HANDOFF.md", "docs/SUPERAGENT_EXPERIMENTS.md",
        ))
        entries = []
        for path in sorted(files):
            if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(repo):
                raise Refused("source_not_regular_in_repository")
            entries.append({"path": path.relative_to(repo).as_posix(),
                            "sha256": sha(path.read_bytes())})
        return entries

    head = git("rev-parse", "HEAD").decode("ascii").strip()
    if not re.fullmatch(r"[0-9a-f]{40,64}", head):
        raise Refused("commit_identity_invalid")
    status = git("status", "--porcelain=v1", "-z", "--untracked-files=all")
    files = manifest()
    if (manifest() != files or git("rev-parse", "HEAD").decode("ascii").strip() != head
            or git("status", "--porcelain=v1", "-z", "--untracked-files=all") != status):
        raise Refused("source_changed_during_freeze")
    return {"commit": head, "dirty": bool(status), "git_status_sha256": sha(status),
            "files": files, "manifest_sha256": sha(encoded(files)),
            "scope": "all_backend_python_and_explicit_protocol_docs_and_dependency_lock",
            "current_source_live_acceptance": "not_run"}


def credential_present(environ):
    reference = environ.get("FORGE_PROVIDER_CREDENTIAL_REF", "")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,127}", reference):
        return False
    # Do not serialize the reference or value, even if the reference is malformed.
    return bool(environ.get(reference, "").strip())


def fresh_workspace(path):
    path = Path(path)
    if not path.is_absolute() or ".." in path.parts:
        raise Refused("workspace_must_be_new_absolute_path")
    if any(parent.is_symlink() for parent in (path, *path.parents)):
        raise Refused("workspace_symlink_forbidden")
    if path.exists():
        raise Refused("workspace_exists_no_resume_or_overwrite")
    if not path.parent.is_dir():
        raise Refused("workspace_parent_must_exist")
    if path.is_relative_to(REPO) and not path.is_relative_to(REPO / ".local"):
        raise Refused("workspace_must_not_modify_repository_sources")
    return path


def budget(attempts):
    """Every ledger row counts, even failures/rejections/unknowns; never refund.

    Unknown usage retains each unreported component's original reservation,
    matching ModelCallBudgetLedger admission accounting. This is an offline
    observation, NOT a Gateway admission guard or a claim of billed usage.
    """
    seen, records, charged_or_reserved, known_complete = set(), [], 0, 0
    for row in attempts:
        identifier = row["attempt_id"]
        if not isinstance(identifier, str) or not identifier or identifier in seen:
            raise Refused("invalid_or_duplicate_attempt")
        seen.add(identifier)
        components = []
        for kind in ("input", "output"):
            reserved, charged = row[kind + "_reserved"], row[kind + "_charged"]
            if (type(reserved) is not int or reserved < 0
                    or (charged is not None and (type(charged) is not int or charged < 0))):
                raise Refused("invalid_attempt_usage")
            components.append(reserved if charged is None else charged)
        usage_known = all(row[k + "_charged"] is not None for k in ("input", "output"))
        state = row["state"]
        if state not in {"settled", "reserved", "rejected", "unknown", "uncertain", "overrun"}:
            raise Refused("unknown_attempt_state")
        charge = sum(components)
        charged_or_reserved += charge
        known_complete += charge if usage_known else 0
        records.append({
            "attempt_id_sha256": sha(identifier.encode()), "state": state,
            "call_id_sha256": sha(row["call_id"].encode()),
            "purpose_sha256": sha(row["purpose"].encode()),
            "model_matches_protocol": row["model_id"] == MODEL,
            "input_reserved": row["input_reserved"], "output_reserved": row["output_reserved"],
            "input_charged": row["input_charged"], "output_charged": row["output_charged"],
            "charged_or_reserved_tokens": charge, "usage_known": usage_known,
        })
    total_calls, total_tokens = OPENING_CALLS + len(records), OPENING_TOKENS + charged_or_reserved
    return {
        "opening_attempts": OPENING_CALLS, "opening_tokens": OPENING_TOKENS,
        "new_attempts": len(records), "new_charged_or_reserved_tokens": charged_or_reserved,
        "new_known_complete_usage_tokens": known_complete,
        "new_unknown_usage_attempts": sum(not r["usage_known"] for r in records),
        "new_unsettled_attempts": sum(r["state"] not in {"settled", "rejected", "overrun"}
                                      for r in records),
        "attempts": records, "stage_attempts": total_calls,
        "stage_charged_or_reserved_tokens": total_tokens,
        "within_caps": (len(records) <= NEW_CALL_CAP and charged_or_reserved <= NEW_TOKEN_CAP
                        and total_calls <= STAGE_CALL_CAP and total_tokens <= STAGE_TOKEN_CAP),
        "new_call_cap": NEW_CALL_CAP, "new_token_cap": NEW_TOKEN_CAP,
        "stage_call_cap": STAGE_CALL_CAP, "stage_token_cap": STAGE_TOKEN_CAP,
        "remaining_stage_attempts": STAGE_CALL_CAP - total_calls,
        "remaining_stage_tokens": STAGE_TOKEN_CAP - total_tokens,
        "maximum_if_new_allocation_fully_used": {
            "attempts": OPENING_CALLS + NEW_CALL_CAP,
            "charged_or_reserved_tokens": OPENING_TOKENS + NEW_TOKEN_CAP,
        },
        "currency_cost": None, "admission_enforced_by_this_script": False,
    }


def protocol(workspace, *, environ=None):
    workspace = fresh_workspace(workspace)
    return {
        "schema_version": 1, "created_at": datetime.now(UTC).isoformat(),
        "mode": "offline_protocol_only", "status": "blocked_not_live_ready",
        "live_execution_available": False, "provider_requests_by_this_command": 0,
        "workspace": str(workspace), "source": source_freeze(), "history": history(),
        "credential_present": credential_present(os.environ if environ is None else environ),
        "budget": budget([]),
        "provider": {"base_url": BASE_URL, "model_id": MODEL,
                     "identity": "operator_requested_not_discovered_or_measured",
                     "credential_transport": "process_environment_only_never_argv_or_logs",
                     "context_window": 100000000,
                     "context_source": "retained_user_declaration_not_spending_authority"},
        "required_gateway_settings_not_applied": {
            "FORGE_MODEL_CALL_LIMIT": "12", "FORGE_MODEL_TOKEN_LIMIT": "160000",
            "FORGE_ENFORCE_TOKEN_BUDGETS": "true", "FORGE_MODEL_CONCURRENCY_LIMIT": "1",
            "FORGE_PROVIDER_MAX_RETRIES": "0", "FORGE_PROVIDER_BASE_URL": BASE_URL,
            "FORGE_ROUTER_MODEL_ID": MODEL,
            "FORGE_ROUTER_OUTPUT_RESERVE": "4096",
        },
        "original_per_task_ceiling_not_enlarged": {
            "calls": 32, "tokens": 500000, "worker_output": 8192, "router_output": 4096,
            "note": "The smaller aggregate 12/160000 always binds first.",
        },
        "scenarios": [
            {"id": "thread_during_execution", "status": "not_run",
             "protocol": [
                 "Use real Agent file work in fresh project alpha with an independent content oracle.",
                 "Observe an active inference barrier, inject one uniquely bound Thread amendment.",
                 "Require actual full read_trigger pages with Core source proof and later model turn.",
                 "Verify FINAL receipt-bound artifact implements the amendment, not just an ack.",
             ]},
            {"id": "project_switch", "status": "not_run",
             "protocol": [
                 "Seed distinguishable alpha/beta fixtures; let Router select alpha then beta.",
                 "Verify real task_project_links and tool scopes/cwd, plus beta final artifact.",
                 "Independently hash alpha before/after beta; wrong-project writes fail.",
                 "Host pre-binding projects or enumerating links alone cannot pass.",
             ]},
            {"id": "post_compaction_process_store_restart_recall", "status": "not_run",
             "protocol": [
                 "Create real Agent history containing a decision and an unfinished todo.",
                 "At a fully settled quiescent boundary, confirm private graceful process exit.",
                 "Host ContextService compacts actual Router history with source/hash receipts.",
                 "Close Store; spawn a new Core process and Store on the SAME new workspace.",
                 "Preserve Router/workspace identities, budgets, attempt IDs and approval bindings.",
                 "Agent must invoke recall_object after restart for three complete objects/two hops.",
                 "Verify Core proofs, pagination, tool transcript order and subsequent model turns.",
                 "Agent final artifact/answer must recover the historical decision AND pending todo.",
                 "Host MemoryService enumeration or prompt-supplied answers are NOT Agent Recall.",
             ]},
        ],
        "reuse": {
            "admission": "forge_core.model_call_budget.ModelCallBudgetLedger",
            "lifecycle": "scripts/phase2/live_core.py:LiveCore(private_control=True)",
            "metrics": "scripts/capability_sprint_metrics.py:read_metrics (audit-ledger only)",
            "tool_proofs": "scripts/capability_continuity_evidence.py:observe",
            "compaction": "forge_core.context_service.ContextService.compact_router",
            "warning": "Do not call verify_superagent_capability.run or compact_and_recall as this driver.",
        },
        "run_rules": [
            "12 calls/160000 tokens TOTAL across all three scenes, Router/planner/reviewer/notice included.",
            "Pre-HTTP durable admission, not periodic observation; all failure/unknown reservations count.",
            "Never start another workspace to reset the 99/1089785 opening or evade new-condition cap.",
            "Single campaign owner required; any other spending requires explicit reconciled history.",
            "No HTTP, scenario, repair, recovery, notice or driver retries; stop on first failure.",
            "One declared quiescent restart only; it is fault injection, not old-experiment recovery.",
            "No broad tool approvals; bind necessary grants and exact parameters before side effects.",
            "Freeze source again before/after live use; commit alone never covers dirty bytes.",
            "Observe <=900s; seal admission first, drain read-only <=130s, then private shutdown.",
            "Record every attempt/usage/failure and unsettled model/tool/action/reservation; never replay.",
            "Unknown usage/effects/cost stay unknown; an artifact claim or handback alone is not PASS.",
        ],
        "gaps": list(GAPS), "failure_code": "live_driver_not_implemented",
        "new_unresolved_side_effects": [], "prior_unknown_effects_retained": True,
        "acceptance": {"thread": "not_run", "project_switch": "not_run", "recall": "not_run"},
    }


def prepare(workspace):
    report = protocol(workspace)
    if not report["credential_present"]:
        raise Refused("environment_credential_missing")
    workspace = Path(report["workspace"])
    # Atomic exclusive claim. Never remove/reuse a partial preparation after failure.
    workspace.mkdir(mode=0o700)
    target = workspace / PROTOCOL_NAME
    with target.open("xb") as stream:
        os.chmod(target, 0o600)
        stream.write(encoded(report))
        stream.flush()
        os.fsync(stream.fileno())
    return report


def audit_ledger(workspace):
    """Audit ONE prepared condition; never migrate DB or report scenario success.

    Reuses existing read-only Sprint metrics. Its independently sampled snapshot
    is labelled separately; accounting/effects below share one SQLite snapshot.
    Even a settled snapshot is not proof that another process cannot start work.
    """
    workspace = Path(workspace)
    if not workspace.is_absolute() or any(p.is_symlink() for p in (workspace, *workspace.parents)):
        raise Refused("audit_workspace_must_be_absolute_without_symlinks")
    plan_path, database = workspace / PROTOCOL_NAME, workspace / "data/forge.sqlite3"
    if plan_path.is_symlink() or database.is_symlink() or database.parent.is_symlink():
        raise Refused("audit_symlink_forbidden")
    plan = json.loads(plan_path.read_bytes())
    if (plan.get("mode") != "offline_protocol_only" or plan.get("workspace") != str(workspace)
            or plan.get("history") != history()
            or plan.get("budget") != budget([])):
        raise Refused("audit_protocol_binding_mismatch")
    if not database.is_file():
        raise Refused("audit_database_missing_no_creation")
    sys.path.insert(0, str(SCRIPTS))
    from capability_sprint_metrics import read_metrics
    from forge_core.settings import Workspace

    metrics = read_metrics(database)
    with closing(sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=5)) as conn:
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA query_only=ON")
        conn.execute("BEGIN")
        identity = Workspace.from_path(workspace).id
        if conn.execute("SELECT id FROM workspace WHERE singleton=1").fetchone()[0] != identity:
            raise Refused("audit_database_workspace_mismatch_no_old_experiments")
        if conn.execute("SELECT 1 FROM model_budget_attempts WHERE workspace_id != ? LIMIT 1",
                        (identity,)).fetchone():
            raise Refused("audit_attempt_workspace_mismatch")
        attempts = [dict(row) for row in conn.execute(
            "SELECT attempt_id,call_id,purpose,state,model_id,input_reserved,output_reserved,"
            "input_charged,output_charged FROM model_budget_attempts ORDER BY created_at,attempt_id"
        )]
        result = budget(attempts)
        effects = {}
        for name, query in {
            "tool_intents": "SELECT COUNT(*) FROM action_intents WHERE state IN ('prepared','executing','uncertain')",
            "worker_tools": "SELECT COUNT(*) FROM worker_tool_calls WHERE state IN ('pending','running','uncertain')",
            "worker_reservations": "SELECT COUNT(*) FROM worker_model_reservations WHERE state='reserved'",
            "active_workers": "SELECT COUNT(*) FROM worker_runs WHERE state IN ('queued','running','review_pending')",
        }.items():
            effects[name] = conn.execute(query).fetchone()[0]
    current_source = source_freeze()
    source_changed = current_source != plan["source"]
    return {
        "observed_at": datetime.now(UTC).isoformat(),
        "status": "observation_only_not_acceptance", "provider_requests_by_this_command": 0,
        "prepared_source": plan["source"], "current_source": current_source,
        "source_changed_since_preparation": source_changed,
        "budget": result, "unresolved_or_active": effects,
        "existing_metrics_separate_snapshot": {
            "snapshot_sha256": metrics["snapshot_sha256"],
            "model_calls": metrics["model_calls"], "known_charged_tokens": metrics["known_charged_tokens"],
            "unknown_usage_attempts": metrics["unknown_usage_attempts"],
        },
        "failure_codes": (["budget_cap_exceeded"] if not result["within_caps"] else [])
        + (["unsettled_or_active_work"] if any(effects.values()) or result["new_unsettled_attempts"] else [])
        + (["model_mismatch"] if any(not r["model_matches_protocol"] for r in result["attempts"]) else [])
        + (["provider_usage_overrun"] if any(r["state"] == "overrun" for r in result["attempts"]) else [])
        + (["unknown_usage_retained"] if result["new_unknown_usage_attempts"] else [])
        + (["source_changed_since_preparation"] if source_changed else []),
        "gateway_failure_details": "not_recorded_in_attempt_table_no_remote_text_published",
        "limitations": "No campaign-wide attribution, runtime seal, tool semantics or Agent Recall proof.",
    }


def main(argv=None):
    parser = SafeParser(description=__doc__)
    parser.add_argument("command", choices=("preflight", "prepare", "audit-ledger"))
    parser.add_argument("--workspace", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "prepare":
            report = prepare(args.workspace)
        elif args.command == "audit-ledger":
            report = audit_ledger(args.workspace)
        else:
            report = protocol(args.workspace)
    except Refused as exc:
        print(json.dumps({"status": "refused", "failure_code": exc.args[0],
                          "provider_requests_by_this_command": 0}))
        return 2
    except Exception:  # noqa: BLE001 - never emit paths, credentials or foreign exception text.
        print(json.dumps({"status": "refused", "failure_code": "offline_preflight_or_audit_failed",
                          "provider_requests_by_this_command": 0}))
        return 2
    print(encoded(report).decode("utf-8"), end="")
    # Offline preparation succeeded, not live readiness or acceptance.
    return 2 if report.get("failure_codes") else 0


if __name__ == "__main__":
    raise SystemExit(main())
