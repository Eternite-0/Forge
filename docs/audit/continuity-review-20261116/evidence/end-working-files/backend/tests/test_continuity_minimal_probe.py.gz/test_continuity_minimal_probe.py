"""Offline protocol/accounting tests. Socket and Provider access are forbidden."""

import importlib.util
import json
import socket
import sqlite3
from pathlib import Path

import pytest

from forge_core.model_budget_schema import migrate_model_budget
from forge_core.model_call_budget import BudgetExceeded, ModelCallBudgetLedger
from forge_core.runtime import ModelCallContext
from forge_core.settings import Workspace
from forge_core.store import Store

SCRIPT = Path(__file__).resolve().parents[1] / "scripts/continuity_minimal_probe.py"
SPEC = importlib.util.spec_from_file_location("continuity_minimal_probe_test", SCRIPT)
probe = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(probe)
SECRET = "OFFLINE_PLACEHOLDER_MUST_NEVER_APPEAR_IN_OUTPUT"
ENV = {"FORGE_PROVIDER_CREDENTIAL_REF": "OFFLINE_CREDENTIAL", "OFFLINE_CREDENTIAL": SECRET}


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def forbidden(*_args, **_kwargs):
        pytest.fail("Network/Provider access is forbidden in this offline suite")

    monkeypatch.setattr(socket.socket, "connect", forbidden)
    monkeypatch.setattr(socket.socket, "connect_ex", forbidden)
    monkeypatch.setattr(socket, "create_connection", forbidden)
    from forge_core.providers import ProviderGateway

    monkeypatch.setattr(ProviderGateway, "generate", forbidden)


@pytest.fixture
def frozen(monkeypatch):
    value = {"commit": "a" * 40, "dirty": True, "files": [], "manifest_sha256": "b" * 64}
    monkeypatch.setattr(probe, "source_freeze", lambda: value.copy())
    return value


def attempt(identifier="one", *, state="settled", inp=100, out=20, reserved=1000):
    return {
        "attempt_id": identifier, "call_id": "call-" + identifier,
        "purpose": "router", "model_id": probe.MODEL, "state": state,
        "input_reserved": reserved, "output_reserved": 200,
        "input_charged": inp, "output_charged": out,
    }


def test_inherits_all_four_failed_conditions_without_refund():
    result = probe.history()
    assert result["attempts"] == result["settled"] == 99
    assert result["charged_or_reserved_tokens"] == 1089785
    records = result["retained_failed_conditions"]
    assert [r["accounting"]["attempts"] for r in records] == [21, 20, 25, 33]
    assert all(r["status"] == "failed" for r in records)
    assert result["previous_closed_stages"]["included_in_this_stage_denominator"] is False


def test_changed_history_fails_closed(tmp_path):
    path = tmp_path / probe.HISTORY_PATH
    path.parent.mkdir(parents=True)
    path.write_text("{}", encoding="utf-8")
    with pytest.raises(probe.Refused, match="historical_anchor_changed"):
        probe.history(tmp_path)


def test_empty_preflight_is_not_new_zero_history_or_live_success(tmp_path, frozen):
    workspace = tmp_path / "fresh"
    result = probe.protocol(workspace, environ=ENV)
    assert not workspace.exists()
    assert result["source"] == frozen
    assert result["status"] == "blocked_not_live_ready"
    assert result["live_execution_available"] is False
    assert result["credential_present"] is True
    assert result["provider_requests_by_this_command"] == 0
    assert result["provider"]["base_url"] == "http://127.0.0.1:7863/v1"
    assert result["provider"]["model_id"] == "global:deepseek-v4.1-flash-sg"
    assert result["budget"]["stage_attempts"] == 99
    assert result["budget"]["stage_charged_or_reserved_tokens"] == 1089785
    assert result["budget"]["maximum_if_new_allocation_fully_used"] == {
        "attempts": 111, "charged_or_reserved_tokens": 1249785,
    }
    assert len(result["scenarios"]) == 3
    assert all(s["status"] == "not_run" for s in result["scenarios"])
    assert all(v == "not_run" for v in result["acceptance"].values())
    assert result["gaps"] and result["failure_code"] == "live_driver_not_implemented"
    assert SECRET not in probe.encoded(result).decode()


def test_prepare_exclusively_claims_workspace_and_never_resumes(tmp_path, frozen, monkeypatch):
    monkeypatch.setenv("FORGE_PROVIDER_CREDENTIAL_REF", "OFFLINE_CREDENTIAL")
    monkeypatch.setenv("OFFLINE_CREDENTIAL", SECRET)
    workspace = tmp_path / "fresh"
    result = probe.prepare(workspace)
    path = workspace / probe.PROTOCOL_NAME
    before = path.read_bytes()
    assert json.loads(before) == result
    assert path.stat().st_mode & 0o077 == 0
    assert workspace.stat().st_mode & 0o077 == 0
    assert SECRET.encode() not in before
    assert list(workspace.iterdir()) == [path]
    with pytest.raises(probe.Refused, match="exists_no_resume"):
        probe.prepare(workspace)
    assert path.read_bytes() == before


@pytest.mark.parametrize("reference", ["", "bad=reference", "bad reference", SECRET + "!"])
def test_invalid_credential_reference_is_not_logged(reference):
    assert not probe.credential_present({"FORGE_PROVIDER_CREDENTIAL_REF": reference})


def test_missing_environment_does_not_read_dotenv_or_create_workspace(tmp_path, frozen, monkeypatch):
    monkeypatch.delenv("FORGE_PROVIDER_CREDENTIAL_REF", raising=False)
    (tmp_path / ".env").write_text("FORGE_PROVIDER_CREDENTIAL_REF=OFFLINE_CREDENTIAL\n"
                                  "OFFLINE_CREDENTIAL=" + SECRET, encoding="utf-8")
    with pytest.raises(probe.Refused, match="environment_credential_missing"):
        probe.prepare(tmp_path / "fresh")
    assert not (tmp_path / "fresh").exists()


def test_existing_and_symlink_workspaces_are_rejected(tmp_path):
    existing = tmp_path / "existing"
    existing.mkdir()
    for path in (existing, Path("relative")):
        with pytest.raises(probe.Refused):
            probe.fresh_workspace(path)
    symlink = tmp_path / "link"
    symlink.symlink_to(existing, target_is_directory=True)
    with pytest.raises(probe.Refused, match="symlink"):
        probe.fresh_workspace(symlink / "new")
    dangling = tmp_path / "dangling"
    dangling.symlink_to(tmp_path / "absent")
    with pytest.raises(probe.Refused, match="symlink"):
        probe.fresh_workspace(dangling)


def test_partial_and_unknown_usage_retain_each_unreported_reservation():
    result = probe.budget([
        attempt(), attempt("reserved", state="reserved", inp=None, out=None),
        attempt("partial", state="unknown", inp=40, out=None),
        attempt("rejected", state="rejected", inp=None, out=None),
    ])
    assert result["new_attempts"] == 4
    assert result["new_charged_or_reserved_tokens"] == 120 + 1200 + 240 + 1200
    assert result["new_known_complete_usage_tokens"] == 120
    assert result["new_unknown_usage_attempts"] == 3
    assert result["new_unsettled_attempts"] == 2
    assert result["stage_attempts"] == 103
    assert result["stage_charged_or_reserved_tokens"] == 1089785 + 2760
    assert result["currency_cost"] is None
    assert result["admission_enforced_by_this_script"] is False


def test_caps_are_aggregate_and_overruns_are_not_clamped():
    assert probe.budget([attempt(str(i)) for i in range(12)])["within_caps"]
    assert not probe.budget([attempt(str(i)) for i in range(13)])["within_caps"]
    assert probe.budget([attempt(inp=159980)])["within_caps"]
    excess = probe.budget([attempt(inp=160000, state="overrun")])
    assert not excess["within_caps"]
    assert excess["new_charged_or_reserved_tokens"] == 160020


@pytest.mark.parametrize("field,value", [
    ("input_reserved", True), ("input_reserved", -1), ("output_charged", -1),
    ("input_charged", 1.5), ("state", "invented"),
])
def test_malformed_usage_never_counts_as_zero(field, value):
    row = attempt()
    row[field] = value
    with pytest.raises(probe.Refused):
        probe.budget([row])


def test_duplicate_attempts_are_not_deduplicated_into_extra_budget():
    with pytest.raises(probe.Refused, match="duplicate_attempt"):
        probe.budget([attempt(), attempt()])


def test_existing_production_ledger_limits_survive_reopening(tmp_path):
    """Exercise actual admission only, never Gateway/HTTP; this isn't live proof."""
    database = tmp_path / "budget.sqlite3"
    with sqlite3.connect(database) as conn:
        migrate_model_budget(conn)
    ledger = ModelCallBudgetLedger(database, token_limit=160000, concurrency_limit=1,
                                   call_limit=12, enforce_token_budgets=True)
    for i in range(12):
        identifier = ledger.admit(ModelCallContext(str(i), "router", "offline"), "local",
                                  probe.MODEL, input_tokens=1, output_tokens=1,
                                  remote_timeout=30)
        ledger.settle(identifier, {"input_tokens": 1, "output_tokens": 1})
    restarted = ModelCallBudgetLedger(database, token_limit=160000, concurrency_limit=1,
                                      call_limit=12, enforce_token_budgets=True)
    with pytest.raises(BudgetExceeded):
        restarted.admit(ModelCallContext("13", "router", "offline"), "local", probe.MODEL,
                        input_tokens=1, output_tokens=1, remote_timeout=30)


def test_production_token_admission_keeps_unknown_reservation_after_reopening(tmp_path):
    database = tmp_path / "budget.sqlite3"
    with sqlite3.connect(database) as conn:
        migrate_model_budget(conn)
    for identifier in ("unknown", "must_not_be_admitted"):
        ledger = ModelCallBudgetLedger(database, token_limit=160000, concurrency_limit=2,
                                       call_limit=12, enforce_token_budgets=True)
        if identifier == "unknown":
            ledger.admit(ModelCallContext(identifier, "router", "offline"), "local", probe.MODEL,
                         input_tokens=155000, output_tokens=5000, remote_timeout=30)
        else:
            with pytest.raises(BudgetExceeded):
                ledger.admit(ModelCallContext(identifier, "router", "offline"), "local", probe.MODEL,
                             input_tokens=1, output_tokens=1, remote_timeout=30)
    with sqlite3.connect(database) as conn:
        assert conn.execute("SELECT COUNT(*) FROM model_budget_attempts").fetchone()[0] == 1


def test_main_sanitizes_foreign_errors_and_has_no_live_command(tmp_path, capsys, monkeypatch):
    def broken(_workspace):
        raise ValueError(SECRET)

    monkeypatch.setattr(probe, "protocol", broken)
    assert probe.main(["preflight", "--workspace", str(tmp_path / "fresh")]) == 2
    output = capsys.readouterr()
    assert SECRET not in output.out + output.err
    assert json.loads(output.out)["failure_code"] == "offline_preflight_or_audit_failed"
    with pytest.raises(SystemExit) as exc:
        probe.main(["run", "--workspace", str(tmp_path / "fresh")])
    assert exc.value.code == 2
    with pytest.raises(SystemExit):
        probe.main(["prepare", "--workspace", str(tmp_path / "fresh"), "--api-key", SECRET])
    output = capsys.readouterr()
    assert SECRET not in output.out + output.err


def test_successful_cli_preflight_and_prepare_are_still_offline(tmp_path, frozen, monkeypatch, capsys):
    workspace = tmp_path / "fresh"
    assert probe.main(["preflight", "--workspace", str(workspace)]) == 0
    assert not workspace.exists()
    result = json.loads(capsys.readouterr().out)
    assert result["live_execution_available"] is False
    monkeypatch.setenv("FORGE_PROVIDER_CREDENTIAL_REF", "OFFLINE_CREDENTIAL")
    monkeypatch.setenv("OFFLINE_CREDENTIAL", SECRET)
    assert probe.main(["prepare", "--workspace", str(workspace)]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result["status"] == "blocked_not_live_ready"
    assert SECRET not in probe.encoded(result).decode()


def test_source_freeze_records_actual_commit_dirty_bytes_and_required_files():
    result = probe.source_freeze()
    assert len(result["commit"]) == 40
    assert result["dirty"] is True
    files = {entry["path"]: entry["sha256"] for entry in result["files"]}
    assert files["backend/scripts/continuity_minimal_probe.py"] == probe.sha(SCRIPT.read_bytes())
    assert "backend/tests/test_continuity_minimal_probe.py" in files
    assert "backend/src/forge_core/worker_continuations.py" in files
    assert "backend/scripts/phase2/live_core.py" in files
    assert result["current_source_live_acceptance"] == "not_run"


def seed_prepared_store(tmp_path, monkeypatch):
    monkeypatch.setenv("FORGE_PROVIDER_CREDENTIAL_REF", "OFFLINE_CREDENTIAL")
    monkeypatch.setenv("OFFLINE_CREDENTIAL", SECRET)
    workspace = tmp_path / "fresh"
    probe.prepare(workspace)
    store = Store(workspace=Workspace.from_path(workspace))
    with store.unit_of_work() as work:
        for identifier, state, inp, out in [("ok", "settled", 10, 20),
                                            ("unknown", "reserved", None, None)]:
            work.connection.execute(
                "INSERT INTO model_budget_attempts(attempt_id,call_id,purpose,workspace_id,"
                "provider_id,model_id,input_reserved,output_reserved,state,created_at,"
                "input_charged,output_charged) VALUES (?,?,?,?,'local',?,100,200,?,1,?,?)",
                (identifier, "call-" + identifier, SECRET, store.workspace.id, probe.MODEL,
                 state, inp, out),
            )
    return workspace, Path(store.path)


def test_audit_reuses_read_only_metrics_and_retains_unknowns_without_raw_data(
    tmp_path, frozen, monkeypatch,
):
    workspace, database = seed_prepared_store(tmp_path, monkeypatch)
    before = database.read_bytes()
    first = probe.audit_ledger(workspace)
    second = probe.audit_ledger(workspace)
    assert database.read_bytes() == before
    assert first.pop("observed_at")
    assert second.pop("observed_at")
    assert first == second
    assert first["status"] == "observation_only_not_acceptance"
    assert first["budget"]["stage_attempts"] == 101
    assert first["budget"]["stage_charged_or_reserved_tokens"] == 1089785 + 330
    assert first["existing_metrics_separate_snapshot"]["model_calls"] == 2
    assert first["existing_metrics_separate_snapshot"]["unknown_usage_attempts"] == 1
    assert "unsettled_or_active_work" in first["failure_codes"]
    assert SECRET not in probe.encoded(first).decode()


def test_audit_refuses_a_database_copied_from_old_workspace(tmp_path, frozen, monkeypatch):
    workspace, database = seed_prepared_store(tmp_path, monkeypatch)
    with sqlite3.connect(database) as conn:
        conn.execute("UPDATE workspace SET id='old-experiment'")
    with pytest.raises(probe.Refused, match="no_old_experiments"):
        probe.audit_ledger(workspace)


def test_audit_rejects_old_workspace_and_never_creates_database(tmp_path, frozen, monkeypatch):
    monkeypatch.setenv("FORGE_PROVIDER_CREDENTIAL_REF", "OFFLINE_CREDENTIAL")
    monkeypatch.setenv("OFFLINE_CREDENTIAL", SECRET)
    workspace = tmp_path / "fresh"
    probe.prepare(workspace)
    with pytest.raises(probe.Refused, match="database_missing"):
        probe.audit_ledger(workspace)
    assert not (workspace / "data").exists()
    # A copied protocol cannot relabel an old historical database as the new condition.
    other = tmp_path / "old"
    other.mkdir()
    (other / probe.PROTOCOL_NAME).write_bytes((workspace / probe.PROTOCOL_NAME).read_bytes())
    with pytest.raises(probe.Refused, match="binding_mismatch"):
        probe.audit_ledger(other)
