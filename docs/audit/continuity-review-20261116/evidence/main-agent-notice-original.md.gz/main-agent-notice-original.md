# 给主代理：continuity fixture 独立审查发现

审查写集仅 `/Users/tracy/Documents/Forge/docs/audit/continuity-review-20261116/`，未改源码/测试，未调用真实 Provider。

## 必须处理的遗漏：3 个新增回归（P2）

审计自跑的 `/Users/tracy/Documents/Forge/docs/audit/continuity-review-20261116/runs/safety-fixtures.xml`：**145 passed / 3 failed**。

失败位置：`/Users/tracy/Documents/Forge/backend/tests/test_worker_core_provenance_superagent.py:103`，测试 `test_real_core_checkpoints_pass_review_and_completion_without_fabricated_action_receipts` 的 `read_trigger`、`recall_object`、`handback_trigger` 三个参数。

原因：`/Users/tracy/Documents/Forge/backend/src/forge_core/independent_review.py` 的 `_review_receipts()` 新增已验证、`context_only=True` 的 Thread 上下文投影；原测试依然要求整个 `receipts` 只有一个 `file_write`。原始 baseline XML 中这三项均通过，因此不属于原 17 个失败。

建议修复合同而非放宽安全：分别验证执行回执与上下文回执。执行集合仍只能含原来真实的 `file_write`；上下文必须先通过 `_verify_worker_context_call`，必须 `context_only=True`，不能伪造 action receipt，不能生成 artifact。继续保留 `call.receipt_id is None`、action_receipts 数量不增、读取无数据库副作用、篡改/跨 run/来源不匹配拒绝等原断言。不能简单删掉断言或改为 `len(receipts)>=1`。

## 覆盖缺口（P2，不能宣称原可行性仍通过）

360k branch、120k operator、L1=180k/L2=360k 四项由“成功构造”改为“原限额不足必须拒绝”在安全意义上合理；没有增加原预算。但这些分支提前返回，不再覆盖原来的成功路径。应保留拒绝用例，并另有明确、合法、预算内的正向分支/独立池/预算交集测试；不能把旧任务涨预算后仍称原任务通过。

## 独立评审的语义验证仍欠缺（P2）

新系统提示要求 Thread 新增要求反映到最终产物，方向正确，但读取完整不等于落实。建议新增离线对照：完整读取后故意遗漏**范围内必需**新增要求，应不能 PASS；范围外 handback 不应授予新工具或权限。现有读取债务/来源证明测试不能替代这个语义对照，也不构成真实模型验收。

## 已确认的结果

- 原 17 个失败均有对应离线通过观察：10 个 fixture 文件 **275 passed**，另一个生命周期测试在安全扩展组通过（同库两次启停，`model_budget_attempts=0`）。不是新的全后端通过结论。
- 两组各自测试前后 diff 一致，但两组之间 `worker_runtime.py` 增加了 DomainError fail-closed 处理，不能合并成一个冻结源完整套件。
- `failure-clusters-fixed.xml` 的 6 failures 是中间态：5 个 `dataclasses.replace(ModelProfile, ...)` 类型错误在当前 fixture 已改为 `model_copy`；剩余旧请求数断言也已修复。不要把中间态当最终，也不要抹去历史。
- `0bef3316a5783348c1f5687d9d584a2cf1eb5e7a` 与 `7c1763bb2ce962a924f2266c55978e1483bd112b` 的 `backend` Git tree 均为 `016a4eadb5034871c00148afda88279224e36822`。

通知方式：本审计任务没有暴露 `send_message_to_thread` 等协调工具；已用任务进度消息即时指出发现，并在此保留可直接转交的消息。未声称已通过工具送达另一个任务。
